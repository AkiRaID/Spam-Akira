# Spam Call Unlimited COID
![image](https://github.com/Xractz/SpamCall/blob/master/spamc.jpg)
Spam Call Unlimited Terbaru menggunakan bahasa pemrograman python

## Cara Install
```
$pkg install python
$pip install requests
$git clone https://github.com/Xractz/SpamCall
$cd SpamCall
$python spam.py
```


Copyright © 2019, Xractz - IndoSec

